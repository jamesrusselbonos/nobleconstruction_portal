<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class googlesheetsController extends Controller
{
    
}
