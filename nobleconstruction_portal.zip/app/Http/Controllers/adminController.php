<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Projects;

use App\User;

use DataTables;


class adminController extends Controller
{

    public function __construct(){

        $this->middleware('revalidate');

        $this->middleware('auth:admin');
    }

    public function admin_manage_project(){

    	return view('manage_project');
    }

    public function admin_manage_customers(){
        
        return view('admin_users');   
    }

    public function edit_project(Request $request){

    	$edit_project = Projects::find($request->txt_id);
        $edit_project->client_id = $request->txt_client_id;
        $edit_project->client_name = $request->txt_client_name;
        $edit_project->client_email = $request->txt_client_email;
        $edit_project->cline_pnumber = $request->txt_client_pnumber;
        $edit_project->job_name = $request->txt_job_name;
        $edit_project->cost = $request->txt_cost;
        $edit_project->description = $request->txt_desc;
        $edit_project->start_date = $request->txt_start_date;
        $edit_project->end_date = $request->txt_end_date;
        $edit_project->location = $request->txt_location;
        $edit_project->status = $request->txt_status;
       	$edit_project->save();

        return redirect()->back();
    }

    public function admin_calendar_view(){
    	$project_calendar = Projects::all();


    	return view('admin_calendar', compact('project_calendar'));
    }

    public function ajaxshowcustomers(){

        $query = User::all();

        return datatables($query)->make(true);
    }

    public function ajaxshowcprojects(){

        $query = Projects::all();

        return datatables($query)
        ->addColumn('action', function($row){
               $btn = '<a type="button"  data-id="'.$row->id.'" class="btn btn-primary btn_p_overview" data-toggle="modal" data-target="#exampleModal"

                    p_id = "'.$row->id.'"
                    p_client_id = "'.$row->client_id.'"
                    p_client_name = "'.$row->client_name.'"
                    p_client_email = "'.$row->client_email.'"
                    p_client_pnumber = "'.$row->cline_pnumber.'"
                    p_job_name = "'.$row->job_name.'"
                    p_cost = "'.$row->cost.'"
                    p_desc = "'.$row->description.'"
                    p_start_date = "'.$row->start_date.'"
                    p_end_date = "'.$row->end_date.'"
                    p_location = "'.$row->location.'"
                    p_status = "'.$row->status.'"

                   ><i class="fa fa-gear"></i>&nbsp;Manage</a>';
               return $btn;
            })
        ->rawColumns(['action'])
        ->make(true);
    }
}
