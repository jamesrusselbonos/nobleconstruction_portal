<?php $__env->startSection('admin_content'); ?>

	<div class="row">
		<div class="card2">
			<div class="card-body">
				<div class="row">
					<div class="col-xl-10">
						<div id='calendar'></div>
					</div>
					<div class="col-xl-2">
						<h6>Legends</h6>
						<ul class="side_nav_ul">
							<li style="color: #5bc0de;"><i class="fa fa-circle" aria-hidden="true">&nbsp;&nbsp;&nbsp;</i>Pending</li>
							<li style="color: #fd7e14 ;"><i class="fa fa-circle" aria-hidden="true">&nbsp;&nbsp;&nbsp;</i>In Progress</li>
							<li style="color: #5cb85c;"><i class="fa fa-circle" aria-hidden="true">&nbsp;&nbsp;&nbsp;</i>Finished</li>
							<li style="color: #d9534f;"><i class="fa fa-circle" aria-hidden="true">&nbsp;&nbsp;&nbsp;</i>Cancelled</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>

	<script type="text/javascript">
	    $(document).ready(function(){
	         $('#calendar').fullCalendar({
	         	plugins: [ 'interaction'],
	         	selectable: true,
	         	selectHelper: true,
	         	height: "auto",
	         	editable: true,
	         	 events : [
	         	 	<?php $__currentLoopData = $project_calendar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projects_calendar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                {
		                    title : '<?php echo e($projects_calendar->client_name . ', ' . $projects_calendar->job_name . ', ' . $projects_calendar->location); ?>',
		                    start : '<?php echo e($projects_calendar->start_date); ?>T00:00:00',
		                    <?php if($projects_calendar->status == 'In Progress'): ?>
		                            color : '#fd7e14',
		                    <?php elseif($projects_calendar->status == 'Finished'): ?>
		                    	color : '#5cb85c',
		                    <?php elseif($projects_calendar->status == 'Cancelled'): ?>
		                    	color : '#d9534f',
		                    <?php else: ?> 
		                    	color : '#5bc0de',
		                    <?php endif; ?>
		                    textColor: 'white',
		                    <?php if($projects_calendar->end_date): ?>
		                            end: '<?php echo e($projects_calendar->end_date); ?>T24:00:00',
		                    <?php endif; ?>
		                },
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	         	 ]

	        });  
	    });
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nobleconstruction_portal\resources\views/admin_calendar.blade.php ENDPATH**/ ?>