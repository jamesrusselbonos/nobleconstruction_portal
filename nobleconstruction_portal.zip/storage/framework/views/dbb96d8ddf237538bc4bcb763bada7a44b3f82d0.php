

<?php $__env->startSection('admin_content'); ?>

	<div class="row">
		 <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
		 	<div class="card_pending">
		 		<div class="card-body">
		 			<h3 style="margin-top: -10px;"><?php echo e($project_pending); ?></h3>
		 			<p style="margin-top: -20px; margin-bottom: -10px;">Pending Projects</p>
		 		</div>
		 	</div>
		 </div>
		 <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
		 	<div class="card_in_progress">
		 		<div class="card-body">
		 			<h3 style="margin-top: -10px;"><?php echo e($project_in_progress); ?></h3>
		 			<p style="margin-top: -20px; margin-bottom: -10px;">In-Progress Projects</p>
		 		</div>
		 	</div>
		 </div>
		 <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
		 	<div class="card_finished">
		 		<div class="card-body">
		 			<h3 style="margin-top: -10px;"><?php echo e($project_finished); ?></h3>
		 			<p style="margin-top: -20px; margin-bottom: -10px;">Finished Projects</p>
		 		</div>
		 	</div>
		 </div>
		 <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12">
		 	<div class="card_cancelled">
		 		<div class="card-body">
		 			<h3 style="margin-top: -10px;"><?php echo e($project_cancelled); ?></h3>
		 			<p style="margin-top: -20px; margin-bottom: -10px;">Cancelled Projects</p>
		 		</div>
		 	</div>
		 </div>
	</div>

	<div class="row" style="margin-top: 20px;">
		<div class="col-xl-7 col-lg-7 col-md-12 col-sm-12">
			<div class="card2">
				<div class="card-header">
					<h5>Projects</h5>
				</div>
				<div class="card-body">
					<div id="myChart" width="400" height="400">
						 <?php echo $chart->renderHtml(); ?>

					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-5 col-lg-5 col-md-12 col-sm-12">
			<div class="row">
				<div class="col-xl-12">
					<div class="card2">
						<!-- <div class="card-header">
							Latest Customers
						</div> -->
						<div class="card-body">
							<h3 style="margin-top: -10px;"><?php echo e($total_customer); ?></h3>
							<p style="margin-top: -20px; margin-bottom: -10px;">Total Customers</p>
						</div>
					</div>
				</div>
				<div style="margin-top: 30px;" class="col-xl-12">
					<div class="card2">
						<div class="card-header">
							<h5>Customer Registered</h5>
						</div>
						<div class="card-body">
							<div id="myChart2" width="200" height="200">
								<?php echo $chart2->renderHtml(); ?>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="row" style="margin-top: 20px;">
		<div class="col-xl-5 col-lg-5 col-md-12 col-sm-12">
			<div class="card2" style="max-height: 540px; overflow-y: auto;">
				<div class="card-header">
					<h5>Latest Customers</h5>
				</div>
				<div class="card-body">
					<div class="row">
						<?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-xl-12">
								<h6 style="margin-top: -10px;"><?php echo e($customers->name); ?></h6>
								<p style="margin-top: -20px;"><?php echo e($customers->email); ?></p>
								<p style="margin-top: -20px;"><?php echo e($customers->phone_number); ?></p>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-7 col-lg-7 col-md-12 col-sm-12">
			<div class="card2">
				<div class="card-header">
					<h5>Calendar</h5>
				</div>
				<div class="card-body">
					<div id='calendar'></div>
				</div>
			</div>
		</div>
	</div>

	<?php echo $chart->renderChartJsLibrary(); ?>

	<?php echo $chart->renderJs(); ?>

	<?php echo $chart2->renderJs(); ?>


	<script>

	    $(document).ready(function(){
	         
	         $('#calendar').fullCalendar({
	         	plugins: [ 'interaction'],
	         	selectable: true,
	         	selectHelper: true,
	         	height: "auto",
	         	editable: true,
	         	 events : [
	         	 	<?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                {
		                    title : '<?php echo e($projects->client_name . ', ' . $projects->job_name . ', ' . $projects->location); ?>',
		                    start : '<?php echo e($projects->start_date); ?>T00:00:00',
		                    <?php if($projects->status == 'In Progress'): ?>
		                            color : '#fd7e14',
		                    <?php elseif($projects->status == 'Finished'): ?>
		                    	color : '#5cb85c',
		                    <?php elseif($projects->status == 'Cancelled'): ?>
		                    	color : '#d9534f',
		                    <?php else: ?> 
		                    	color : '#5bc0de',
		                    <?php endif; ?>
		                    textColor: 'white',
		                    <?php if($projects->end_date): ?>
		                            end: '<?php echo e($projects->end_date); ?>T24:00:00',
		                    <?php endif; ?>
		                },
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	         	 ]

	        });  
	    });

	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nobleconstruction_portal\resources\views/admin_dashboard.blade.php ENDPATH**/ ?>