<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row main">
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12">
            <div class="row">
                <div class="col-xl-12">
                    <div class="picture"></div>
                </div>
            </div>
            <div class="bg-light" id="sidebar-wrapper">
                <div class="sidebar-heading">Navigation </div>
                <div class="list-group list-group-flush">
                    <a href="#" class="list-group-item list-group-item-action bg-light">Calendar</a>
                    <a href="#" class="list-group-item list-group-item-action bg-light">Projects</a>
                    <a href="#" class="list-group-item list-group-item-action bg-light">Add A Project</a>
                </div>
            </div>
        </div>
        <div class="col-xl-9 col-lg-9 col-md-9 col-sm-12">
            <div class="row welcome_header">
                <div class="row">
                    <div class="col-xl-12 welcome_text">
                        <h5>Welcome!</h5>
                        <h2 class="client_name"><?php echo e(Auth::user()->name); ?></h2>
                        <h6 class="client_address"><i class="fa fa-map" aria-hidden="true">&nbsp;&nbsp;&nbsp;</i>POB 1191 Woodburn, OR, 97071</h6>
                    </div>
                </div>
            </div>
            <div class="row jobs_wrapper">
                <?php echo $__env->yieldContent('job_content'); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nobleconstruction_portal\resources\views/home.blade.php ENDPATH**/ ?>